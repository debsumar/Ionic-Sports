import { Component } from "@angular/core";
import {
  IonicPage,
  LoadingController,
  NavController,
  NavParams,
} from "ionic-angular";
import moment from "moment";
import { Storage } from "@ionic/storage";
import { MatchModel } from "../models/match.model";
import { Apollo } from "apollo-angular";
import { HttpLink } from "apollo-angular-link-http";
import {
  CommonService,
  ToastMessageType,
  ToastPlacement,
} from "../../../../services/common.service";
import { FirebaseService } from "../../../../services/firebase.service";
import { SharedServices } from "../../../services/sharedservice";
import gql from "graphql-tag";
import { first } from "rxjs/operators";

/**
 * Generated class for the MatchhistoryPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: "page-matchhistory",
  templateUrl: "matchhistory.html",
})
export class MatchhistoryPage {
  isTournament = "Tournament";
  // isHistoryPoints = "HistoryPoints";
  FetchMatchesInput: FetchMatchesInput = {
    ParentClubKey: "",
    MemberKey: "",
    FetchType: 5,
  };
  historymatches: MatchModel[] = [];
  filteredMatches: MatchModel[] = [];
  // filteredMatches: MatchModel[] = [];

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private apollo: Apollo,
    private httpLink: HttpLink,
    public commonService: CommonService,
    public loadingCtrl: LoadingController,
    public storage: Storage,
    public fb: FirebaseService,
    public sharedservice: SharedServices
  ) {
    this.commonService.category.pipe(first()).subscribe((data) => {
      if (data == "match_history") {
        this.storage.get("userObj").then((val) => {
          val = JSON.parse(val);
          if (val.$key != "") {
            this.FetchMatchesInput.ParentClubKey =
              val.UserInfo[0].ParentClubKey;
          }
          this.getHistory();
        });
      }
    });
  }

  ionViewDidLoad() {}

  ionViewWillEnter() {
    console.log("ionViewDidLoad MatchhistoryPage");

    // this.storage.get("userObj").then((val) => {
    //   val = JSON.parse(val);
    //   if (val.$key != "") {
    //     this.FetchMatchesInput.ParentClubKey = val.UserInfo[0].ParentClubKey;
    //   }
    //   this.getHistory();
    // });
  }

  gotoMatchdetailsPage(history) {
    this.navCtrl.push("MatchdetailsPage", {
      match: history,
      isHistory:true
    });
  }

  formatMatchStartDate(date) {
    //return moment(+date, "YYYY-MM-DD hh:mm:ss").format("DD-MMM-YYYY, hh:mm");
    return moment(date, "YYYY-MM-DD HH:mm").format("DD-MMM-YYYY, hh:mm A");
  }

  getHistory = () => {
    this.commonService.showLoader("Fetching matches history...");

    const historyQuery = gql`
      query fetchMatches($fetchMatchesInput: FetchMatchesInput!) {
        fetchMatches(fetchMatchesInput: $fetchMatchesInput) {
          Id
          IsActive
          IsEnable
          CreatedAt
          CreatedBy
          Activity {
            ActivityName
          }
          Result {
            ResultStatus
            Winner {
              Id
            }
          }
          MatchVisibility
          GameType
          MatchType
          PaymentType
          ResultStatus
          MatchStatus
          VenueName
          Details
          MatchStartDate
          Capacity
          MatchTitle
          Hosts {
            Name
          }
          Teams {
            Id
            TeamName
            TeamPoint
            ResultStatus
            Participants {
              User {
                FirstName
                LastName
                FirebaseKey
              }
            }
          }
        }
      }
    `;
    this.apollo
      .query({
        query: historyQuery,
        // fetchPolicy: type ? "network-only" : "cache-first",
        fetchPolicy: "network-only",
        variables: {
          fetchMatchesInput: this.FetchMatchesInput,
        },
      })
      .subscribe(
        ({ data }) => {
          console.log("matches data" + JSON.stringify(data["fetchMatches"]));
          this.commonService.hideLoader();
          this.historymatches = data["fetchMatches"]
          this.historymatches.forEach(element => {
            element['MatchTypeName'] = element.MatchType == 0?"Single":"Double"
          });
          this.historymatches = this.historymatches.sort(function (a, b) {
            return moment(b.MatchStartDate, 'YYYY-MM-DD').diff(moment(a.MatchStartDate, 'YYYY-MM-DD'));
          });
          this.filteredMatches = JSON.parse(
            JSON.stringify(this.historymatches)
          );
        },
        (err) => {
          this.commonService.hideLoader();
          console.log(JSON.stringify(err));
          this.commonService.toastMessage(
            "Failed to fetch matches history",
            2500,
            ToastMessageType.Error,
            ToastPlacement.Bottom
          );
        }
      );
  };



  getFilterItems(ev: any) {
    // Reset items back to all of the items
    // this.initializeItems();
    // set val to the value of the searchbar
    let val = ev.target.value;
    // if the value is an empty string don't filter the items
    if (val && val.trim() != "") {
      this.filteredMatches = this.historymatches.filter((item) => {
        if (item.MatchTitle != undefined) {
          if(item.MatchTitle.toLowerCase().indexOf(val.toLowerCase()) > -1) return true;
        }
        if (item['MatchTypeName'] != undefined) {
          if (item['MatchTypeName'].toLowerCase().indexOf(val.toLowerCase()) > -1) return true;
        }
        if (item.Activity.ActivityName != undefined) {
          if (item.Activity.ActivityName.toLowerCase().indexOf(val.toLowerCase()) > -1) return true;
        }
        if (item.Hosts[0].Name != undefined) {
          if(item.Hosts[0].Name.toLowerCase().indexOf(val.toLowerCase()) > -1) return true;
        }
      });
    } else this.initializeItems();
  }

  initializeItems() {
    this.filteredMatches = this.historymatches;
  }
}

export class FetchMatchesInput {
  ParentClubKey: string;
  MemberKey: string;
  FetchType: number;
}
