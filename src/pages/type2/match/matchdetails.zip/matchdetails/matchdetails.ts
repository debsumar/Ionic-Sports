import { Component } from "@angular/core";
import { Apollo } from "apollo-angular";
import { HttpLink } from "apollo-angular-link-http";
import {
  ActionSheetController,
  IonicPage,
  LoadingController,
  NavController,
  NavParams,
} from "ionic-angular";
import {
  CommonService,
  ToastMessageType,
  ToastPlacement,
} from "../../../../services/common.service";
import { FirebaseService } from "../../../../services/firebase.service";
import { SharedServices } from "../../../services/sharedservice";
import { Storage } from "@ionic/storage";
import gql from "graphql-tag";
import { MatchModel, ParticipantModel } from "../models/match.model";
import * as moment from "moment";
/**
 * Generated class for the MatchdetailsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: "page-matchdetails",
  templateUrl: "matchdetails.html",
})
export class MatchdetailsPage {
  activeType: boolean = true;
  invitedType: boolean = true;
  UserInvitationStatus = {
    MatchId: "",
    MemberKey: "",
  };
  participants: ParticipantModel[] = [];
  match: any;
  history: any;

  InvitationResponseInput = {
    MatchId: "",
    MemberKey: "",
    ParticipationStatus: 0,
    InviteStatus: 3,
  };
  isHistory: any;

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private apollo: Apollo,
    private httpLink: HttpLink,
    public commonService: CommonService,
    public loadingCtrl: LoadingController,
    public storage: Storage,
    public fb: FirebaseService,
    public sharedservice: SharedServices,
    public actionSheetCtrl: ActionSheetController
  ) {
    this.match = this.navParams.get("match");
    this.isHistory = this.navParams.get("isHistory");
    this.UserInvitationStatus.MatchId = this.match.Id;
    this.InvitationResponseInput.MatchId = this.match.Id;
    console.log(this.UserInvitationStatus);
  }

  ionViewDidLoad() {
    console.log("ionViewDidLoad MatchdetailsPage");
  }

  ionViewWillEnter() {
    this.storage.get("userObj").then((val) => {
      val = JSON.parse(val);
      if (val.$key != "") {
        this.getInvitedPlayers();
        // this.UserInvitationStatus.MemberKey = val.UserInfo[0].ParentClubKey;
      }
    });
  }

  gotoMatchInvitePlayers() {
    let invitedMembers = []
    this.participants.forEach((members) =>{
      invitedMembers.push(members.User.FirebaseKey)
    })
    this.navCtrl.push("MatchinviteplayersPage", {
      selectedmatchId: this.UserInvitationStatus.MatchId,
      selectedmemberkey: this.UserInvitationStatus.MemberKey,
      invitedMembers :invitedMembers
    });
  }
  gotoMatchCompose() {
    this.navCtrl.push("Matchcompose");
  }

  formatMatchStartDate(date) {
    return moment(date, "YYYY-MM-DD HH:mm").format("DD-MMM-YYYY, hh:mm A");
  }

  changeType(val) {
    this.activeType = val;
    this.invitedType = !val;
  }

  presentActionSheet(selectedparticipant: ParticipantModel) {
    let actionSheet = this.actionSheetCtrl.create({
      title: "Do you want to cancel the invite?",
      buttons: [
        {
          text: "Yes",
          role: "destructive",
          icon: "checkmark",
          handler: () => {
            this.invite(selectedparticipant);
          },
        },
        {
          text: "No",
          role: "cancel",
          icon: "close",
          handler: () => {
            console.log("Cancel clicked");
          },
        },
      ],
    });

    actionSheet.present();
  }

  invite(selectedparticipant) {
    this.InvitationResponseInput.MemberKey =
      selectedparticipant.User.FirebaseKey;
    this.apollo
      .mutate({
        mutation: gql`
          mutation inviteResponse(
            $InvitationResponseInput: UserInviteResponseInput!
          ) {
            inviteResponse(InvitationResponseInput: $InvitationResponseInput)
          }
        `,
        variables: { InvitationResponseInput: this.InvitationResponseInput },
      })
      .subscribe(
        ({ data }) => {
          this.commonService.hideLoader();
          console.log("invite data" + data["inviteResponse"]);
          this.commonService.toastMessage(
            "Player(s) invite cancelled successfully",
            2500,
            ToastMessageType.Success,
            ToastPlacement.Bottom
          );
        },
        (err) => {
          this.commonService.hideLoader();
          console.log(JSON.stringify(err));
          this.commonService.toastMessage(
            "Player invite failed",
            2500,
            ToastMessageType.Error,
            ToastPlacement.Bottom
          );
        }
      );
  }

  getInvitedPlayers = () => {
    // this.commonService.showLoader("Fetching invited players...");
    const participantsStatusQuery = gql`
      query checkAllParticipantsStatus($UserInput: UserInvitationStatus!) {
        checkAllParticipantsStatus(UserInput: $UserInput) {
          Id
          User {
            FirstName
            LastName
            Gender
            DOB
            FirebaseKey
          }
          ParticipationStatus
          InviteStatus
          InviteType
          TotalPoints
        }
      }
    `;
    this.apollo
      .query({
        query: participantsStatusQuery,
        fetchPolicy: "network-only",
        variables: {
          UserInput: this.UserInvitationStatus,
        },
      })
      .subscribe(
        ({ data }) => {
          console.log(
            "matches data" + JSON.stringify(data["checkAllParticipantsStatus"])
          );
          this.commonService.hideLoader();
          this.participants = data["checkAllParticipantsStatus"];
          // this.filteredMatches = data["fetchMatches"];
        },
        (err) => {
          this.commonService.hideLoader();
          console.log(JSON.stringify(err));
          this.commonService.toastMessage(
            "Failed to fetch invited players list",
            2500,
            ToastMessageType.Error,
            ToastPlacement.Bottom
          );
        }
      );
  };

  getoResult(){
    this.navCtrl.push('PublishresultPage',{
      matchId : this.match.Id,
      teams :this.match.Teams
    })
  }
}
export class UserInvitationStatus {
  MatchId: string;
  MemberKey: string;
}

export class InvitationResponseInput {
  MatchId: String;
  MemberKey: String;
  ParticipationStatus: number;
  InviteStatus: number;
}
